import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/login/login.vue'
import Home from '@/components/home/home.vue'
import Users from '@/components/user/user.vue'
import Department from '@/components/department/department.vue'
import NewsKind from '@/components/newsKind/newsKind.vue'
import Hospital from '@/components/hospital/hospital.vue'
import Doctor from '@/components/doctor/doctor.vue'
import Healthnew from '@/components/healthnew/healthnew.vue'
import DiseaseKnowledge from '@/components/DiseaseKnowledge/diseaseKnowledge.vue'
import DiseaseKinds from '@/components/DiseaseKinds/diseaseKinds.vue'
import Problems from '@/components/problems/problems.vue'
import Answers from '@/components/Problems/answers.vue'
Vue.use(Router)

export default new Router({
  routes: [
    {
      name: 'login',
      path: '/login',
      component: Login
    },
    {
      name: 'home',
      path: '/',
      component: Home,
      children: [{
        name: 'users',
        path: 'users',
        component: Users
      },
      {
        name: 'department',
        path: 'department',
        component: Department
      },
      {
        name: 'hospitals',
        path: 'hospitals',
        component: Hospital
      },
      {
        name: 'newsKinds',
        path: 'newsKinds',
        component: NewsKind
      },
      {
        name: 'doctor',
        path: 'doctor',
        component: Doctor
      },
      {
        name: 'healthnew',
        path: 'healthnew',
        component: Healthnew
      },
      {
        name: 'diseaseKnowledge',
        path: 'diseaseKnowledge',
        component: DiseaseKnowledge
      },
      {
        name: 'diseaseKinds',
        path: 'diseaseKinds',
        component: DiseaseKinds
      },
      {
        name: 'problems',
        path: 'problems',
        component: Problems
      },
      {
        name: 'answers',
        path: 'answers',
        component: Answers
      }]
    }
  ]
})
