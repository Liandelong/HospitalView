<template>
<el-card class="box-card">
<el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>疾病知识管理</el-breadcrumb-item>
  <el-breadcrumb-item>疾病类型</el-breadcrumb-item>
</el-breadcrumb>

<el-row class="el-row-class">
    <el-col>
          <el-input placeholder="请输入内容" v-model="query" class="inputSearch">
          <el-button slot="append" icon="el-icon-search" @click="searchNewsKind()"></el-button>
          </el-input>
          <el-button type="success" @click="showAddNewsKind()">添加疾病类型</el-button>
    </el-col>
</el-row>

 <el-table
    :data="tableData"
    style="width: 100%">
    <el-table-column
      label="编号"
      prop="id">
    </el-table-column>
    <el-table-column
      label="疾病类型"
      prop="name">
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          type="primary" 
          icon="el-icon-edit" 
          circle
          @click="handleEdit(scope.$index, scope.row)"></el-button>
        <el-button
          type="danger" 
          icon="el-icon-delete" 
          circle
          @click="handleDelete(scope.$index, scope.row)"></el-button>
      </template>
    </el-table-column>
  </el-table>
      <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageNumber"
      :page-sizes="[5, 10, 20, 50]"
      :page-size="5"
      layout="total, sizes, prev, pager, next"
      :total="total">
    </el-pagination>

  <el-dialog title="添加疾病类型" :visible.sync="createVisible">
  <el-form :model="addNewsKindForm">
       <el-form-item label="类型名" >
      <el-input v-model="addNewsKindForm.name" autocomplete="off"></el-input>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="createVisible = false">取 消</el-button>
    <el-button type="primary" @click="CreateNewsKind()">确 定</el-button>
  </div>
</el-dialog>

  <el-dialog title="修改疾病类型" :visible.sync="editVisible">
  <el-form :model="editNewsKindForm">
       <el-form-item label="类型名" >
      <el-input v-model="editNewsKindForm.name" autocomplete="off"></el-input>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="editVisible = false">取 消</el-button>
    <el-button type="primary" @click="EditNewsKind()">确 定</el-button>
  </div>
   </el-dialog>
</el-card>
</template>

<script>
export default {
    data(){
        return{
             query:'',
            pageNumber:1,
            pageSize:5,
            total:0,
            tableData:[],
            createVisible:false,
            editVisible:false,
            addNewsKindForm:{
                name:''
            },
            editNewsKindForm:{
                name:''
            }        
        }
    },
    created(){
        this.getNewsKindList()
    },
    methods:{
             //搜索
      searchNewsKind(){
            this.getNewsKindList()
      },
      handleSizeChange(val){
            this.pageSize=val;
            this.pageNumber=1;
             this.getNewsKindList()
      },
      handleCurrentChange(val){
              this.pageNumber=val;
               this.getNewsKindList()
      },
        async getNewsKindList(){
          const filters={
               query:this.query,
               pageNumber:this.pageNumber,
               pageSize:this.pageSize,
            }
            const res=await this.$http.post('DiseaseKinds/GetDiseaseKinds',filters)
                        console.log(res);
            const {data,status}=res
            if(status===200){                
              this.tableData=data
              this.tableData=data.data
              this.total=data.totel
            }
            else{

            }
        },
        async showAddNewsKind(){
            this.createVisible=true;
            this.addNewsKindForm={};
        },
        async handleEdit(index,row){
             this.editNewsKindForm=row;
             this.editVisible=true;
        },
        async handleDelete(index,row) {
          this.$confirm('是否删除该类型?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
           const res= await this.$http.delete(`DiseaseKinds/delete/${row.id}`) 
           if(res.status===200){
               this.$message.success("删除成功");
               this.getNewsKindList();
           } 
           else{
                this.$message.error("删除失败");
           }      
        }).catch(() => {
         
        });
      },
        async CreateNewsKind(){
            console.log(this.addNewsKindForm);
           const res= await this.$http.post('DiseaseKinds/CreateOrEditDiseaseKind',this.addNewsKindForm) 
           if(res.status===200){
               this.createVisible=false;
               this.$message.success("添加成功");
               this.getNewsKindList();
           } 
           else{
                this.$message.error("添加失败");
           }      
      },
      async EditNewsKind(){
           const res=await this.$http.post('DiseaseKinds/CreateOrEditDiseaseKind',this.editNewsKindForm)
          console.log(res);
          const {data,status}=res
            if(status===200){
               this.editVisible=false;
               this.getNewsKindList();
            }
            else{
                this.$message.error("修改失败");
            }
      }
    }
}
</script>

<style>
.box-card{
    height: 100%;
}
.inputSearch{
    width: 300px;
}
.el-row-class{
    margin-top: 20px;
    margin-bottom: 20px;
}
</style>