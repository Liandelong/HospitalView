<template>
<el-card class="box-card">
<el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>用户管理</el-breadcrumb-item>
  <el-breadcrumb-item>用户列表</el-breadcrumb-item>
</el-breadcrumb>

<el-row class="el-row-class">
    <el-col>
          <el-input placeholder="请输入内容" v-model="query" class="inputSearch">
          <el-button slot="append" icon="el-icon-search" @click="searchUser()"></el-button>
          </el-input>
          <el-button type="success" @click="showAddUser()">添加用户</el-button>
    </el-col>
</el-row>

 <el-table
    :data="tableData"
    style="width: 100%">
    <el-table-column
      label="用户名"
      prop="userName">
    </el-table-column>
    <el-table-column
      label="电话"
      prop="telephone">
    </el-table-column>
    <el-table-column
      label="身份证"
      prop="idCard">
    </el-table-column>
    <el-table-column
      label="密码"
      prop="password">
    </el-table-column>
     <el-table-column
      label="是否管理员"
      prop="isAdmin">
      <template slot-scope="scope">
          <el-switch
  v-model="scope.row.isAdmin"
  active-color="#13ce66"
  inactive-color="#ff4949">
</el-switch>
      </template>
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          type="primary" 
          icon="el-icon-edit" 
          circle
          @click="handleEdit(scope.$index, scope.row)"></el-button>
        <el-button
          type="danger" 
          icon="el-icon-delete" 
          circle
          @click="handleDelete(scope.$index, scope.row)"></el-button>
      </template>
    </el-table-column>
  </el-table>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageNumber"
      :page-sizes="[5, 10, 20, 50]"
      :page-size="5"
      layout="total, sizes, prev, pager, next"
      :total="total">
    </el-pagination>

  <el-dialog title="添加用户" :visible.sync="createVisible">
  <el-form :model="userForm">
    <el-form-item label="用户名称" >
      <el-input v-model="userForm.userName" autocomplete="off"></el-input>
    </el-form-item>
    
       <el-form-item label="密码" >
      <el-input v-model="userForm.password" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="电话号码" >
      <el-input v-model="userForm.telephone" autocomplete="off"></el-input>
    </el-form-item>
       <el-form-item label="身份证号" >
      <el-input v-model="userForm.idCard" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="是否管理员" >
      <el-switch
       v-model="userForm.isAdmin"
       active-color="#13ce66"
       inactive-color="#ff4949">
       </el-switch>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="createVisible = false">取 消</el-button>
    <el-button type="primary" @click="CreateOrEditUser()">确 定</el-button>
  </div>
</el-dialog>

  <el-dialog title="修改用户" :visible.sync="editVisible">
  <el-form :model="editForm">
    <el-form-item label="用户名称" >
      <el-input v-model="editForm.userName" autocomplete="off"></el-input>
    </el-form-item>
       <el-form-item label="密码" >
      <el-input v-model="editForm.password" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="电话号码" >
      <el-input v-model="editForm.telephone" autocomplete="off"></el-input>
    </el-form-item>
       <el-form-item label="身份证号" >
      <el-input v-model="editForm.idCard" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="是否管理员" >
      <el-switch
       v-model="editForm.isAdmin"
       active-color="#13ce66"
       inactive-color="#ff4949">
       </el-switch>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="editVisible = false">取 消</el-button>
    <el-button type="primary" @click="EditUser()">确 定</el-button>
  </div>
</el-dialog>
</el-card>
</template>

<script>
export default {
    data(){
        return{
             query:'',
            pageNumber:1,
            pageSize:5,
            total:0,
            tableData:[],
            userForm:{
                userName:'',
                telephone:'',
                idCard:'',
                password:'',
                isAdmin:false
            },
            editForm:{
                userName:'',
                telephone:'',
                idCard:'',
                password:'',
                isAdmin:false
            },
            createVisible:false,
            editVisible:false
        }
    },
    created(){
             this.getUserList()
    },
    methods:{
            //搜索
      searchUser(){
            this.getUserList()
      },
      handleSizeChange(val){
            this.pageSize=val;
            this.pageNumber=1;
             this.getUserList()
      },
      handleCurrentChange(val){
              this.pageNumber=val;
               this.getUserList()
      },
       async getUserList(){
           const filters={
               query:this.query,
               pageNumber:this.pageNumber,
               pageSize:this.pageSize,
            }
            const res=await this.$http.post('User/GetUsers',filters)
            const {data,status}=res
            if(status===200){
              console.log(data);
              this.tableData=data.data
              this.total=data.totel
            }
            else{

            }
      },
      async handleEdit(index, row) {
          this.editVisible=true;
          this.editForm=row;
          console.log(this.editForm);
      },
      async EditUser(){
          const res=await this.$http.post('User/CreateOrEditUser',this.editForm)
          console.log(res);
          const {data,status}=res
            if(status===200){
               this.editVisible=false;
               this.getUserList();
            }
            else{
                this.$message.error("修改失败");
            }
      },
      async handleDelete(index, row) {
          this.$confirm('是否删除该用户?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
           const res= await this.$http.delete(`user/delete/${row.id}`) 
           if(res.status===200){
               this.$message.success("删除成功");
               this.getUserList();
           } 
           else{
                this.$message.error("删除失败");
           }      
        }).catch(() => {
         
        });
      },
      showAddUser(){
           this.createVisible=true;
           this.userForm={};
      },
      async CreateOrEditUser(){
          console.log(this.userForm)
           const res= await this.$http.post('user/CreateOrEditUser',this.userForm) 
           if(res.status===200){
               this.createVisible=false;
               this.$message.success("添加成功");
               this.getUserList();
           } 
           else{
                this.$message.error("添加失败");
           }      
      }
    }
}
</script>

<style>
.box-card{
    height: 100%;
}
.inputSearch{
    width: 300px;
}
.el-row-class{
    margin-top: 20px;
    margin-bottom: 20px;
}
</style>