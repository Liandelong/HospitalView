<template>
<el-card class="box-card">
<el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>回答问题</el-breadcrumb-item>
</el-breadcrumb>

<el-row class="el-row-class">
    <el-col>
            <label class="labelText">问题：</label> <label v-text="this.$route.params.title"></label>
            <el-button class="goBack" type="success" @click="goBack()">返回问题列表</el-button>
    </el-col>
</el-row>

<el-row class="el-row-class" :gutter="20">
    <el-col :span="18">
          <textarea class="textarea" v-model="content"  autocomplete="off">           
          </textarea>          
    </el-col>
    <el-col :span="2"></el-col>
    <el-col :span="4">
      <el-button class="addbtn" type="success" @click="addAnswers()">回答</el-button>
    </el-col>
</el-row>


<el-row class="el-row-class">
    <el-col>
          <el-input placeholder="请输入内容" v-model="query" class="inputSearch">
          <el-button slot="append" icon="el-icon-search" @click="searchNewsKind()"></el-button>
          </el-input>
    </el-col>
</el-row>

 <el-table
    :data="tableData"
    style="width: 100%">
    <el-table-column
      label="编号"
      prop="id">
    </el-table-column>
    <el-table-column
      label="回答内容"
      prop="info">
    </el-table-column>
    <el-table-column label="回答者" prop="another">       
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          type="danger" 
          icon="el-icon-delete" 
          circle
          @click="handleDelete(scope.$index, scope.row)"></el-button>
      </template>
    </el-table-column>
  </el-table>
</el-card>
</template>

<script>
export default {
    data(){
        return{
             query:'',
            tableData:[],
            createVisible:false,
            editVisible:false,
            content:""  
        }
    },
    created(){
        this.getNewsKindList()
    },
    methods:{
                     //搜索
      searchNewsKind(){
            this.getNewsKindList()
      },
      handleSizeChange(val){
            this.pageSize=val;
            this.pageNumber=1;
             this.getNewsKindList()
      },
      handleCurrentChange(val){
              this.pageNumber=val;
               this.getNewsKindList()
      },
        async getNewsKindList(){
          const filters={
              probliemId:this.$route.params.id
            }
            const res=await this.$http.post('Answers/GetAnswers',filters)
                        console.log(res);
            const {data,status}=res
            if(status===200){                
              this.tableData=data.data
            }
            else{

            }
        },
       async addAnswers(){
           var userId= localStorage.getItem("userId")
           var problemId=this.$route.params.id
           const createorEditAnswerDto={
               id:0,
               userId:parseInt(userId),
               problemId:problemId,
               content:this.content
           }
           console.log(createorEditAnswerDto)
           const res=await this.$http.post('Answers/CreateOrEditAnswer',createorEditAnswerDto)
            console.log(res)
            if(res.status===200){ 
                this.getNewsKindList()               
                this.$message.success("回复成功");
            }
            else{
                 this.$message.error("回复失败");
            }
        },
        goBack(){
             this.$router.push({
                    name: 'problems'
                })
        },
        async handleDelete(index,row) {
          this.$confirm('是否删除该类型?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
           const res= await this.$http.delete(`Answers/delete/${row.id}`) 
           if(res.status===200){
               this.$message.success("删除成功");
               this.getNewsKindList();
           } 
           else{
                this.$message.error("删除失败");
           }      
        }).catch(() => {
         
        });
      }
    }
}
</script>

<style>
.box-card{
    height: 100%;
}
.inputSearch{
    width: 300px;
}
.el-row-class{
    margin-top: 20px;
    margin-bottom: 20px;
}
.textarea{
    width:100%;
    height:100px;
}
.addbtn{
     margin-top: 70px;
     margin-left: 30px;
}
.labelText{
    font-weight: bold;
    color: blue;
}
.goBack{
    margin-left: 50px;
}
</style>