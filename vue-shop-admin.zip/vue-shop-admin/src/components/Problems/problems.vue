<template>
<el-card class="box-card">
<el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>经典问答管理</el-breadcrumb-item>
  <el-breadcrumb-item>问题</el-breadcrumb-item>
</el-breadcrumb>

<el-row class="el-row-class">
    <el-col>
          <el-input placeholder="请输入内容" v-model="query" class="inputSearch">
          <el-button slot="append" icon="el-icon-search" @click="searchNewsKind()"></el-button>
          </el-input>
    </el-col>
</el-row>

 <el-table
    :data="tableData"
    style="width: 100%">
    <el-table-column
      label="编号"
      prop="id">
    </el-table-column>
    <el-table-column
      label="问题"
      prop="title">
      <template slot-scope="scope">
          <el-link type="primary" v-text="scope.row.title" @click="linkToAnswer(scope.$index, scope.row)"></el-link>
      </template>
    </el-table-column>
    <el-table-column label="提问者" prop="another">       
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          type="danger" 
          icon="el-icon-delete" 
          circle
          @click="handleDelete(scope.$index, scope.row)"></el-button>
      </template>
    </el-table-column>
  </el-table>
</el-card>
</template>

<script>
export default {
    data(){
        return{
             query:'',
            pageNumber:1,
            pageSize:5,
            total:0,
            tableData:[],
            createVisible:false,
            editVisible:false      
        }
    },
    created(){
        this.getNewsKindList()
    },
    methods:{
             //搜索
      searchNewsKind(){
            this.getNewsKindList()
      },
      handleSizeChange(val){
            this.pageSize=val;
            this.pageNumber=1;
             this.getNewsKindList()
      },
      handleCurrentChange(val){
              this.pageNumber=val;
               this.getNewsKindList()
      },
        async getNewsKindList(){
          const filters={
               query:this.query,
               pageNumber:this.pageNumber,
               pageSize:this.pageSize,
            }
            const res=await this.$http.post('Problems/GetProblemList',filters)
                        console.log(res);
            const {data,status}=res
            if(status===200){                
              this.tableData=data.data
              this.total=data.totel
            }
            else{

            }
        },
        async linkToAnswer(index,row){
             this.$router.push({
                    name: 'answers',
                    params:row
                })
        },
        async handleDelete(index,row) {
          this.$confirm('是否删除该类型?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
           const res= await this.$http.delete(`Problems/delete/${row.id}`) 
           if(res.status===200){
               this.$message.success("删除成功");
               this.getNewsKindList();
           } 
           else{
                this.$message.error("删除失败");
           }      
        }).catch(() => {
         
        });
      }
    }
}
</script>

<style>
.box-card{
    height: 100%;
}
.inputSearch{
    width: 300px;
}
.el-row-class{
    margin-top: 20px;
    margin-bottom: 20px;
}
</style>