<template>
<el-card class="box-card">
<el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>疾病知识管理</el-breadcrumb-item>
  <el-breadcrumb-item>疾病列表</el-breadcrumb-item>
</el-breadcrumb>

<el-row class="el-row-class">
    <el-col>
          <el-input placeholder="请输入内容" v-model="query" class="inputSearch">
          <el-button slot="append" icon="el-icon-search" @click="searchHealthNews()"></el-button>
          </el-input>
          <el-button type="success" @click="showAddHealthNews()">添加疾病</el-button>
    </el-col>
</el-row>

 <el-table
    :data="tableData"
    style="width: 100%">
    <el-table-column
      label="疾病名称"
      prop="title">
    </el-table-column>
    <el-table-column
      label="资源"
      prop="source">
    </el-table-column>
     <el-table-column
      label="疾病图片链接"
      prop="image_url">
    </el-table-column>
    <el-table-column
      label="疾病类型"
      prop="diseaseKindName">
    </el-table-column>
      <el-table-column
      label="创建时间"
      prop="dateTime">
    </el-table-column>
        <el-table-column
      label="疾病详细"
      prop="content">
    </el-table-column>
     <el-table-column
      label="是否视频内容"
      prop="videoSrc">
      <template slot-scope="scope">
    <el-switch
  v-model="scope.row.videoSrc"
  active-color="#13ce66"
  inactive-color="#ff4949">
</el-switch>
      </template>
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          type="primary" 
          icon="el-icon-edit" 
          circle
          @click="handleEdit(scope.$index, scope.row)"></el-button>
        <el-button
          type="danger" 
          icon="el-icon-delete" 
          circle
          @click="handleDelete(scope.$index, scope.row)"></el-button>
      </template>
    </el-table-column>
  </el-table>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageNumber"
      :page-sizes="[5, 10, 20, 50]"
      :page-size="5"
      layout="total, sizes, prev, pager, next"
      :total="total">
    </el-pagination>

  <el-dialog title="添加疾病" :visible.sync="createVisible">
  <el-form :model="HealthNewsForm">
    <el-form-item label="疾病名称" >
      <el-input v-model="HealthNewsForm.title" autocomplete="off"></el-input>
    </el-form-item>
       <el-form-item label="疾病图片链接" >
      <el-input v-model="HealthNewsForm.image_url" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="资源" >
      <el-input v-model="HealthNewsForm.source" autocomplete="off"></el-input>
    </el-form-item>
       <el-form-item label="疾病类型" >
       <template >
          <el-select v-model="HealthNewsForm.diseaseKindId" placeholder="请选择">
            <el-option
                v-for="item in newsKinds"
                :key="item.id"
                :label="item.name"
                :value="item.id">
            </el-option>
          </el-select>
       </template>
    </el-form-item>
    <el-form-item label="疾病详细">
      <textarea class="textarea" v-model="HealthNewsForm.content" autocomplete="off"></textarea>
    </el-form-item>
    <el-form-item label="是否视频内容" >
      <el-switch
       v-model="HealthNewsForm.videoSrc"
       active-color="#13ce66"
       inactive-color="#ff4949">
       </el-switch>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="createVisible = false">取 消</el-button>
    <el-button type="primary" @click="CreateOrEditHealthNews()">确 定</el-button>
  </div>
</el-dialog>

  <el-dialog title="修改疾病" :visible.sync="editVisible">
  <el-form :model="editForm">
        <el-form-item label="疾病名称" >
      <el-input v-model="editForm.title" autocomplete="off"></el-input>
    </el-form-item>
       <el-form-item label="疾病图片链接" >
      <el-input v-model="editForm.image_url" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="资源" >
      <el-input v-model="editForm.source" autocomplete="off"></el-input>
    </el-form-item>
       <el-form-item label="疾病类型" >
       <template >
          <el-select v-model="editForm.diseaseKindId"  placeholder="请选择">
            <el-option
                v-for="item in newsKinds"
                :key="item.diseaseKindId"
                :label="item.name"
                :value="item.id">
            </el-option>
          </el-select>
       </template>
    </el-form-item>
    <el-form-item label="疾病详细">
      <textarea class="textarea" v-model="editForm.content" autocomplete="off"></textarea>
    </el-form-item>
    <el-form-item label="是否视频内容" >
      <el-switch
       v-model="editForm.videoSrc"
       active-color="#13ce66"
       inactive-color="#ff4949">
       </el-switch>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="editVisible = false">取 消</el-button>
    <el-button type="primary" @click="EditHealthNews()">确 定</el-button>
  </div>
</el-dialog>
</el-card>
</template>

<script>
export default {
    data(){
        return{
             query:'',
            pageNumber:1,
            pageSize:5,
            total:0,
            tableData:[],
            HealthNewsForm:{
                title:'',
                image_url:'',
                source:'',
                videoSrc:false,
                diseaseKindId:'',
                content:''
            },
            editForm:{
                title:'',
                image_url:'',
                source:'',
                videoSrc:false,
                diseaseKindId:'',
                content:''
            },
            createVisible:false,
            editVisible:false,
            newsKinds:[]    
        }
    },
    created(){
             this.getHealthNewsList()
             this.GetNewsKinds();
    },
    methods:{
            //搜索
      searchHealthNews(){
            this.getHealthNewsList()
      },
      handleSizeChange(val){
            this.pageSize=val;
            this.pageNumber=1;
             this.getHealthNewsList()
      },
      handleCurrentChange(val){
              this.pageNumber=val;
               this.getHealthNewsList()
      },
       async getHealthNewsList(){
           const filters={
               query:this.query,
               pageNumber:this.pageNumber,
               pageSize:this.pageSize,
            }
            const res=await this.$http.post('DiseaseKnowledge/GetDiseaseKnowledges',filters)
            const {data,status}=res
            if(status===200){
              console.log(data);
              this.tableData=data.data
              this.total=data.totel
            }
            else{

            }
      },
      async handleEdit(index, row) {
          this.editVisible=true;
          this.editForm=row;
          console.log(this.editForm);
      },
      async EditHealthNews(){
          const editHealthNew={
                id:this.editForm.id,
                title:this.editForm.title,
                image_url:this.editForm.image_url,
                source:this.editForm.source,
                videoSrc:this.editForm.videoSrc,
                diseaseKindId:this.editForm.diseaseKindId,
                content:this.editForm.content
          }
                    console.log(editHealthNew);
          const res=await this.$http.post('DiseaseKnowledge/CreateOrEditDiseaseKnowledge',editHealthNew)
          console.log(res);
          const {data,status}=res
            if(status===200){
               this.editVisible=false;
               this.getHealthNewsList();
            }
            else{
                this.$message.error("修改失败");
            }
      },
      async handleDelete(index, row) {
          this.$confirm('是否删除该用户?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
           const res= await this.$http.delete(`DiseaseKnowledge/delete/${row.id}`) 
           if(res.status===200){
               this.$message.success("删除成功");
               this.getHealthNewsList();
           } 
           else{
                this.$message.error("删除失败");
           }      
        }).catch(() => {
         
        });
      },
      showAddHealthNews(){
           this.createVisible=true;
           this.HealthNewsForm={};
      },
      async CreateOrEditHealthNews(){
          console.log(this.HealthNewsForm)
           const res= await this.$http.post('DiseaseKnowledge/CreateOrEditDiseaseKnowledge',this.HealthNewsForm) 
           if(res.status===200){
               this.createVisible=false;
               this.$message.success("添加成功");
               this.getHealthNewsList();
           } 
           else{
                this.$message.error("添加失败");
           }      
      },
      async GetNewsKinds(){
            const parm={};
            const newsKinds=await this.$http.post('DiseaseKinds/GetDiseaseKinds',parm)
            const {data,status}=newsKinds
            if(status===200){                
              this.newsKinds=data.data
            }
            else{

            }
      }
    }
}
</script>

<style>
.box-card{
    height: 100%;
}
.inputSearch{
    width: 300px;
}
.el-row-class{
    margin-top: 20px;
    margin-bottom: 20px;
}
.textarea{
    width:100%;
    height:100px;
}
</style>