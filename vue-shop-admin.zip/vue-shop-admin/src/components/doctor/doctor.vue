<template>
<el-card class="box-card">
<el-breadcrumb separator-class="el-icon-arrow-right">
  <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
  <el-breadcrumb-item>医院管理</el-breadcrumb-item>
  <el-breadcrumb-item>医生</el-breadcrumb-item>
</el-breadcrumb>

<el-row class="el-row-class">
    <el-col>
          <el-input placeholder="请输入内容" v-model="query" class="inputSearch">
          <el-button slot="append" icon="el-icon-search" @click="search()"></el-button>
          </el-input>
          <el-button type="success" @click="showAddDoctor()">添加医生</el-button>
    </el-col>
</el-row>

 <el-table
    :data="tableData"
    style="width: 100%">
    <el-table-column
      label="编号"
      prop="id">
    </el-table-column>
    <el-table-column
      label="医生名称"
      prop="doctorName">
    </el-table-column>
        <el-table-column
      label="科室"
      prop="departmentName">
    </el-table-column>
        <el-table-column
      label="医院"
      prop="hospitalName">
    </el-table-column>
        <el-table-column
      label="医生简介"
      prop="resume">
    </el-table-column>
     <el-table-column
      label="图片链接"
      prop="pictureLink">
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          type="primary" 
          icon="el-icon-edit" 
          circle
          @click="handleEdit(scope.$index, scope.row)"></el-button>
        <el-button
          type="danger" 
          icon="el-icon-delete" 
          circle
          @click="handleDelete(scope.$index, scope.row)"></el-button>
      </template>
    </el-table-column>
  </el-table>

    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageNumber"
      :page-sizes="[5, 10, 20, 50]"
      :page-size="5"
      layout="total, sizes, prev, pager, next"
      :total="totel">
    </el-pagination>

  <el-dialog title="添加医生" :visible.sync="createVisible">
  <el-form :model="addDoctorForm">
       <el-form-item label="医生名称" >
      <el-input v-model="addDoctorForm.doctorName" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="科室" >
               <template >
          <el-select v-model="addDoctorForm.departmentId" placeholder="请选择">
            <el-option
                v-for="item in departments"
                :key="item.id"
                :label="item.departmentName"
                :value="item.id">
            </el-option>
          </el-select>
               </template>
    </el-form-item>
    <el-form-item label="医院" >
       <template >
          <el-select v-model="addDoctorForm.hospitalId" placeholder="请选择">
            <el-option
                v-for="item in hospitals"
                :key="item.id"
                :label="item.hospitalName"
                :value="item.id">
            </el-option>
          </el-select>
       </template>
    </el-form-item>
    <el-form-item label="医生图片链接" >
      <el-input v-model="addDoctorForm.pictureLink" autocomplete="off"></el-input>
    </el-form-item>
     <el-form-item label="简介" >
      <el-input v-model="addDoctorForm.resume" autocomplete="off"></el-input>
    </el-form-item>
   </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="createVisible = false">取 消</el-button>
    <el-button type="primary" @click="CreateDoctor()">确 定</el-button>
  </div>
</el-dialog>

  <el-dialog title="修改医生" :visible.sync="editVisible">
   <el-form :model="editDoctorForm">
       <el-form-item label="医生名称" >
      <el-input v-model="editDoctorForm.doctorName" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="科室" >
                     <template >
          <el-select v-model="editDoctorForm.departmentId" placeholder="请选择">
            <el-option
                v-for="item in departments"
                :key="item.id"
                :label="item.departmentName"
                :value="item.id">
            </el-option>
          </el-select>
               </template>
    </el-form-item>
    <el-form-item label="医院" >
       <template >
          <el-select v-model="editDoctorForm.hospitalId" placeholder="请选择">
            <el-option
                v-for="item in hospitals"
                :key="item.id"
                :label="item.hospitalName"
                :value="item.id">
            </el-option>
          </el-select>
       </template>
    </el-form-item>
    <el-form-item label="医生图片链接" >
      <el-input v-model="editDoctorForm.pictureLink" autocomplete="off"></el-input>
    </el-form-item>
     <el-form-item label="简介" >
      <el-input v-model="editDoctorForm.resume" autocomplete="off"></el-input>
    </el-form-item>
   </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="editVisible = false">取 消</el-button>
    <el-button type="primary" @click="EditDoctor()">确 定</el-button>
  </div>
</el-dialog>

</el-card>
</template>

<script>
export default {
    data(){
        return{
            query:'',
            pageNumber:1,
            pageSize:5,
            totel:0,
            tableData:[],
            createVisible:false,
            editVisible:false,
            addDoctorForm:{
                doctorName:'',
                doctorAddress:'',
                pictureLink:'',
                resume:'',
                departmentId:'',
                hospitalId:''
            },
            editDoctorForm:{
                doctorName:'',
                doctorAddress:'',
                pictureLink:'',
                resume:'',
                departmentId:'',
                hospitalId:''
            },
            hospitals:[],
            departments:[]     
        }
    },
    created(){
        this.getDoctorList()
        this.GetHospitals();
        this.GetDepartments();
    },
    methods:{
         //搜索
      search(){
            this.getDoctorList()
      },
      handleSizeChange(val){
            this.pageSize=val;
            this.pageNumber=1;
             this.getDoctorList()
      },
      handleCurrentChange(val){
              this.pageNumber=val;
               this.getDoctorList()
      },
        async getDoctorList(){
            const filters={
               query:this.query,
               pageNumber:this.pageNumber,
               pageSize:this.pageSize,
            };
            const res=await this.$http.post('Doctor/GetDoctors',filters)
            const {data,status}=res
            if(status===200){                
              this.tableData=data.data
              this.totel=data.totel
              console.log(data);
            }
            else{

            }
        },
        async showAddDoctor(){
            this.addDoctorForm={};           
            this.createVisible=true;
        },
        async handleEdit(index,row){
             this.editDoctorForm=row;
             console.log(this.editDoctorForm);
             this.editVisible=true;
        },
        async handleDelete(index,row) {
          this.$confirm('是否删除该医生?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
           const res= await this.$http.delete(`Doctor/delete/${row.id}`) 
           if(res.status===200){
               this.$message.success("删除成功");
               this.getDoctorList();
           } 
           else{
                this.$message.error("删除失败");
           }      
        }).catch(() => {
         
        });
      },
        async CreateDoctor(){
            console.log(this.addDoctorForm);
           const res= await this.$http.post('Doctor/CreateOrEditDoctor',this.addDoctorForm) 
           if(res.status===200){
               this.createVisible=false;
               this.$message.success("添加成功");
               this.getDoctorList();
           } 
           else{
                this.$message.error("添加失败");
           }      
      },
      async EditDoctor(){
           const res=await this.$http.post('Doctor/CreateOrEditDoctor',this.editDoctorForm)
          console.log(res);
          const {data,status}=res
            if(status===200){
               this.editVisible=false;
               this.getDoctorList();
            }
            else{
                this.$message.error("修改失败");
            }
      },
      async GetHospitals(){
             const parm={};
            const resHospital=await this.$http.post('Hospital/GetHospitals',parm)
            const {data,status}=resHospital
            if(status===200){                
              this.hospitals=data.data
            }
            else{

            }
      },
      async GetDepartments(){
            const parm={};
            const resDepartment=await this.$http.post('Department/GetDepartments',parm)
            const {data,status}=resDepartment
            if(status===200){                
              this.departments=data.data
            }
            else{

            }
      }
    }
}
</script>

<style>
.box-card{
    height: 100%;
}
.inputSearch{
    width: 300px;
}
.el-row-class{
    margin-top: 20px;
    margin-bottom: 20px;
}
</style>