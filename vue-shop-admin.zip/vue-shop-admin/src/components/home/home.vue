<template>
<el-container class="container">
    <el-header class="header">
        <el-row>
            <el-col :span="4">
                <div class="grid-content bg-purple">
                    <h3></h3>
                </div>
            </el-col>
            <el-col :span="18" class="middle">
                <h3>医院管理后台</h3>
            </el-col>
            <el-col :span="2">
                <div class="grid-content bg-purple">
                    <a class="loginout" @click.prevent="handleLoginout()" href="#">退出</a>
                </div>
            </el-col>
        </el-row>
    </el-header>
    <el-container>
        <el-aside class="aside" width="200px">
            <el-menu class="el-menu-vertical-demo" :router="true" :unique-opened=true>
                <el-submenu index="1">
                    <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>用户管理</span>
                    </template>
                    <el-menu-item index="users">
                        <i class="el-icon-location"></i>用户列表
                    </el-menu-item>
                </el-submenu>
                <el-submenu index="2">
                    <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>医院管理</span>
                    </template>
                    <el-menu-item index="doctor">
                        <i class="el-icon-location"></i>医生
                    </el-menu-item>
                    <el-menu-item index="department">
                        <i class="el-icon-location"></i>科室
                    </el-menu-item>
                    <el-menu-item index="hospitals">
                        <i class="el-icon-location"></i>医院
                    </el-menu-item>
                </el-submenu>
                <el-submenu index="3">
                    <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>新闻管理</span>
                    </template>
                    <el-menu-item index="healthnew">
                        <i class="el-icon-location"></i>新闻资讯
                    </el-menu-item>
                    <el-menu-item index="newskinds">
                        <i class="el-icon-location"></i>新闻类型
                    </el-menu-item>
                </el-submenu>
                <el-submenu index="4">
                    <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>疾病知识管理</span>
                    </template>
                    <el-menu-item index="diseaseKnowledge">
                        <i class="el-icon-location"></i>疾病
                    </el-menu-item>
                    <el-menu-item index="diseaseKinds">
                        <i class="el-icon-location"></i>疾病类型
                    </el-menu-item>
                </el-submenu>
                <el-submenu index="5">
                    <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>经典问题管理</span>
                    </template>
                    <el-menu-item index="problems">
                        <i class="el-icon-location"></i>问题
                    </el-menu-item>
                </el-submenu>
            </el-menu>
        </el-aside>
        <el-main class="main">
            <router-view></router-view>
        </el-main>
    </el-container>
</el-container>
</template>

<script>
export default {
    data(){
        return{

        }
    },
    created(){
          console.log(this.$route.params)
    },
    methods: {
        handleLoginout() {
            localStorage.clear()
            this.$message.success('退出成功')
            this.$router.push({
                name: 'login'
            })
        }
    }
}
</script>

<style>
.container {
    height: 100%;
}

.header {
    background-color: #d3dce6;
}

.aside {
    background-color: #d3dce6;
}

.main {
    background-color: #e9eef3;
}

.middle {
    text-align: center;
}

.loginout {
    line-height: 60px;
    text-decoration: none;
}
</style>
