
import axios from 'axios'

const HttpServer = {}

HttpServer.install = function (Vue) {
    axios.defaults.baseURL='http://39.108.145.219:5000/api'//'https://localhost:44365/api'//
    // 4. 添加实例方法
    Vue.prototype.$http = axios
  }

export default HttpServer