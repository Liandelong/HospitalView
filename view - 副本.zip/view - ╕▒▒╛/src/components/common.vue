<script type="text/javascript">
  // 定义一些公共的属性和方法 小程序的地址
  const httpUrl =  'http://39.108.145.219:5000/api'

  // 暴露出这些属性和方法
  export default {
    httpUrl,
 
  }
</script>