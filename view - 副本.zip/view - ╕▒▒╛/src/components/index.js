import uniCalendar from "@/components/uni-calendar/uni-calendar"
import uniSegmentedControl from "@/components/uni-segmented-control/uni-segmented-control"
import uniGrid from "@/components/uni-grid/uni-grid.vue"
import uniGridItem from "@/components/uni-grid-item/uni-grid-item.vue"
const Loading={

    install:function(Vue){
        Vue.component('uniCalendar',uniCalendar)
        Vue.component('uniSegmentedControl',uniSegmentedControl)
        Vue.component('uniGrid',uniGrid)
        Vue.component('uniGridItem',uniGridItem)
    }
}
export default Loading