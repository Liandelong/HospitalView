<template>
	<view class="ui-form ui-border-t">
		<form id="entry_form">
			<p />
			<view class="ui-form-item ui-border-b"  >
				<!-- <view> -->
				<label>
					用户名：
				</label>
				<input type="text" id="name2" v-model="message.userName" :disabled="true"  placeholder="用户名">
			<!-- </view> -->
			</view>

						<view class="ui-form-item ui-border-b">
				<label>
					电话号码：
				</label>
				<input type="text" id="Tel" v-model="message.telephone" :disabled="true" placeholder="电话号码">
			</view>
			<view class="ui-form-item ui-border-b">
				<label>
					身份证号：
				</label>
				<input type="text" id="Tel" v-model="message.idCard" :disabled="true" placeholder="电话号码">
			</view>


		</form>
		<view class="ui-btn-wrap">
			<view style="width:100%;">
				<button class="submit" type="primary" @tap="nextPage">确认</button>
			</view>
		</view>

	</view>

</template>
<script>
export default {
	data(){
	return {
	message:{
	userName:undefined,
	telephone: undefined,
	password: undefined,
	idCard: undefined,
	isAdmin: false	
		}
	}
	},
	methods: {
		nextPage(){
							uni.switchTab({
				    url: '/pages/wkiwi-user/wkiwi-user'
				});
		},
	  },
	onLoad() {
	var user_Message = uni.getStorageSync("user_Message");
	 Object.keys(this.message).forEach(key => {
          this.message[key] = user_Message[key]
        })
  }
}
</script>
<style>
	.uni-form-item .title {
		padding: 20rpx 0;
		
    display: inline-block;
	}
</style>
