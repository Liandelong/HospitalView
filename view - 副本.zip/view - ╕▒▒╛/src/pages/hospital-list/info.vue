<!--本页面由uniapp切片工具生成，uni-app切片-可视化设计工具(一套代码编译到7个平台iOS、Android、H5、小程序)，软件下载地址：http://www.ymznkf.com/new_view_669.htm -->
<template>
	<view class="YmContent">
			<view class="info_96">
				<view class="info_61">
					<text decode="true" class="info_62">头像</text>
					<image v-on:click="photo_63_click()"  :src="message.pictureLink" mode="scaleToFill" border="0"    class="photo"></image>
				</view>


				<view class="info_74">
				</view>
				<view v-on:click="row2_75_click()" class="row2">
					<text decode="true" class="info_76">医院名称</text>
					<text decode="true" class="mobile">{{message.hospitalName}}</text>
				</view>
				<view class="info_69">
				</view>
				<view v-on:click="row3_70_click()" class="row3">
					<text decode="true" class="info_71">地址</text>
					<text decode="true" class="ids">{{message.hospitalAddress}}</text>
				
				</view>

								<view class="info_74">
				</view>
				<view v-on:click="row2_75_click()" class="resume">
					<!-- <text decode="true" class="info_76">备注</text> -->
					<text decode="true" class="mobile">{{message.resume}}</text>
				</view>
				<view class="info_83">
				</view>
			</view>
		

		<view class="loading">{{loadingText}}</view>
		<view class="ymBbottom"></view>
	</view>
</template>

<script>
import info from "./info.js";
export default info;




</script>

<style lang="scss" scoped>
   @import './info.scss'
</style>