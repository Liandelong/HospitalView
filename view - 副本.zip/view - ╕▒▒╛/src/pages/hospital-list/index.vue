<template>
    <view>
        <view class="uni-padding-wrap">
            <!-- infoList 显示数组 -->
    <view >
        <lv-select
        @handleSearch="handleSearch"
        @change ="change"
        placeholder = "请输入信息"
        :infoList="infoList"  
        v-model="searchValue"
        type="primary"
        :uniShadow="false"
		:loading="false"
        ></lv-select>
    </view>
            <view class="uni-comment" >


            <block v-for="(i,index) in list"  :key="index">
                <view class="uni-comment-list" v-on:click="toMessage(i.id)"   >
                    <view class="uni-comment-face">
                        <image :src="i.pictureLink" mode="widthFix"></image>
                    </view>
                    <view class="uni-comment-body">
                        <view class="uni-comment-top">
                            <text>{{i.hospitalName}}</text>
                        </view>
                        <view class="uni-comment-date">
                            <text>{{i.hospitalAddress}}</text>
                        </view>
                        <view class="uni-comment-content"></view>
                            <view class="uni-comment-date">
                            <view>{{i.resume}}</view>
                            <!-- <view class="uni-comment-replay-btn">{{i.hospitalName}}</view>  -->
                        </view>
                    </view>
                </view>
</block>


            </view>



        </view>
    </view>
</template>

<script>
import lvSelect from '../../components/lv-select/lv-select.vue'
	import {
		GetHospitals
	} from '@/api/hospital/hospital.js'
    export default {
        
        data() {
            return {
				title: "评论界面",
				searchValue:undefined,
                infoList:[],
                list:[],
            }
		},
		methods: {
            toMessage(id){
             uni.navigateTo({
					url: '/pages/hospital-list/info?id=' + id
				})
            },
			handleSearch(value){
                this.searchValue=value
               this.getMessage()
			},
			change(){
			//	alert("2")
            },
            getMessage(){
      
                   GetHospitals({query:this.searchValue}).then(data => { 
					//data为一个数组，数组第一项为错误信息，第二项为返回数据
					var [error, res] = data;
					if(res.statusCode==200){
                           this.list =res.data.data
					}else{

                }
            })
            }
        },
        //GetDoctors
        	onLoad() {
            this.getMessage()
        },
    }
</script>

<style>
    /* comment */
    page {
        background-color: #f8f8f8;
    }

    .uni-padding-wrap {
        padding: 30upx;
    }

    view {
        font-size: 28upx;
    }

    .uni-comment {
        padding: 5rpx 0;
        display: flex;
        flex-grow: 1;
        flex-direction: column;
    }

    .uni-comment-list {
        flex-wrap: nowrap;
        padding: 10rpx 0;
        margin: 10rpx 0;
        width: 100%;
        display: flex;
    }

    .uni-comment-face {
        width: 70upx;
        height: 70upx;
        border-radius: 100%;
        margin-right: 20upx;
        flex-shrink: 0;
        overflow: hidden;
    }

    .uni-comment-face image {
        width: 100%;
        border-radius: 100%;
    }

    .uni-comment-body {
        width: 100%;
    }

    .uni-comment-top {
        line-height: 1.5em;
        justify-content: space-between;
    }

    .uni-comment-top text {
        color: #0A98D5;
        font-size: 24upx;
    }

    .uni-comment-date {
        line-height: 38upx;
        flex-direction: row;
        justify-content: space-between;
        display: flex !important;
        flex-grow: 1;
    }

    .uni-comment-date view {
        color: #666666;
        font-size: 24upx;
        line-height: 38upx;
    }

    .uni-comment-content {
        line-height: 1.6em;
        font-size: 28upx;
        padding: 8rpx 0;
    }

    .uni-comment-replay-btn {
        background: #FFF;
        font-size: 24upx;
        line-height: 28upx;
        padding: 5rpx 20upx;
        border-radius: 30upx;
        color: #333 !important;
        margin: 0 10upx;
    }
</style>
