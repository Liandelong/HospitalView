<template>
	<view class="content">

		<image class="logo" src="/static/logo.png"></image>
		    <view >
        <lv-select
        @handleSearch="handleSearch"
        @change ="change"
        placeholder = "请输入信息"
        :infoList="infoList"  
        v-model="searchValue"
        type="primary"
        :uniShadow="false"
		:loading="false"
        ></lv-select>
    </view>
		<view>
		
			<button type="primary" @click="godoctor">找医生</button>
	
		</view>
		<view style="margin-top:5px">
			<button type="primary" @click="gohospital">找医院</button>
		</view>
    				<view style="margin-top:5px">
			<button type="primary" @click="goquestions1">提问</button>
		</view>
				<view style="margin-top:5px">
			<button type="primary" @click="goquestions">经典问答</button>
		</view>
<view class="content">
    <load-refresh
      ref="loadRefresh"
      :heightReduce="10"
      :backgroundCover="'#FFFFFF'"
      :pageNo="currPage"
      :totalPageNo="totalPage" 
      @loadMore="loadMore" 
      @refresh="refresh">
      <view slot="content-list">
        <!-- 数据列表 -->
        <view v-for="(item,index) in list" :key="index">
       <div class="test-component"  @click="goAnswer">
   			 <hm-talk-card :options="item" ></hm-talk-card>
  		</div>
        </view>
      </view>
    </load-refresh>
  </view>

	</view>
</template>

<script>
	import {
		GetNewsKinds
	} from '@/api/register/register.js'
	import loadRefresh from '@/components/load-refresh/load-refresh.vue'
	import HmTalkCard from '@/components/hm-talk-card/index.vue'
	export default {
  components: {
	loadRefresh,
	HmTalkCard
  },
		data() {
			return {
				title: 'Hello',
				infoList:[],
				searchValue:undefined,
				list: [
					{
          avator:
            '/static/hm-talk-card/images/1.png',
          name: '黄三环',
          stateimg:
            '/static/hm-talk-card/images/img_25252_0_3.png',
          text: '19个月宝宝吃完退烧药又开始发烧了怎么回事',
          iconfriendsHelp:
            '/static/hm-talk-card/images/img_25252_0_0.png',
          num: '234',
          like: '喜欢',
          iconTest:
            '/static/hm-talk-card/images/img_25252_0_1.png',
          commentNum: '67',
          comments: '条回复'
        },{
          avator:
            '/static/hm-talk-card/images/2.jpg',
          name: '万大大',
          stateimg:
            '/static/hm-talk-card/images/img_25252_0_3.png',
          text: '2岁8个月宝宝膝盖扭伤不能走路怎么办',
          iconfriendsHelp:
            '/static/hm-talk-card/images/img_25252_0_0.png',
          num: '114',
          like: '喜欢',
          iconTest:
            '/static/hm-talk-card/images/img_25252_0_1.png',
          commentNum: '36',
          comments: '条回复'
        },{
          avator:
            '/static/hm-talk-card/images/3.jpg',
          name: '朱小平',
          stateimg:
            '/static/hm-talk-card/images/img_25252_0_3.png',
          text: '岁孩子天天晚上吐为什么',
          iconfriendsHelp:
            '/static/hm-talk-card/images/img_25252_0_0.png',
          num: '344',
          like: '喜欢',
          iconTest:
            '/static/hm-talk-card/images/img_25252_0_1.png',
          commentNum: '112',
          comments: '条回复'
		},{
          avator:
            '/static/hm-talk-card/images/4.jpg',
          name: '万大全',
          stateimg:
            '/static/hm-talk-card/images/img_25252_0_3.png',
          text: '胃隐隐的痛该如何治疗？',
          iconfriendsHelp:
            '/static/hm-talk-card/images/img_25252_0_0.png',
          num: '341',
          like: '喜欢',
          iconTest:
            '/static/hm-talk-card/images/img_25252_0_1.png',
          commentNum: '112',
          comments: '条回复'
		},{
          avator:
            '/static/hm-talk-card/images/5.jpg',
          name: '小洲村',
          stateimg:
            '/static/hm-talk-card/images/img_25252_0_3.png',
          text: '胃隐隐的痛该如何治疗？',
          iconfriendsHelp:
            '/static/hm-talk-card/images/img_25252_0_0.png',
          num: '341',
          like: '喜欢',
          iconTest:
            '/static/hm-talk-card/images/img_25252_0_1.png',
          commentNum: '112',
          comments: '条回复'
		},{
          avator:
            '/static/hm-talk-card/images/6.jpg',
          name: '娃三环',
          stateimg:
            '/static/hm-talk-card/images/img_25252_0_3.png',
          text: '人得了癔病怎么治疗好？',
          iconfriendsHelp:
            '/static/hm-talk-card/images/img_25252_0_0.png',
          num: '141',
          like: '喜欢',
          iconTest:
            '/static/hm-talk-card/images/img_25252_0_1.png',
          commentNum: '142',
          comments: '条回复'
		},{
          avator:
            '/static/hm-talk-card/images/7.jpg',
          name: '卤虾王',
          stateimg:
            '/static/hm-talk-card/images/img_25252_0_3.png',
          text: '1岁5个月孩子吃啥拉啥怎么回事',
          iconfriendsHelp:
            '/static/hm-talk-card/images/img_25252_0_0.png',
          num: '121',
          like: '喜欢',
          iconTest:
            '/static/hm-talk-card/images/img_25252_0_1.png',
          commentNum: '142',
          comments: '条回复'
		}
		
		
		
		], // 数据集
        		currPage: 1, // 当前页码
				totalPage: 1, // 总页数
				
			}
		},
		onLoad() {

		},
		methods: {
			      // 上划加载更多
      loadMore() {
        console.log('loadMore')
        // 请求新数据完成后调用 组件内loadOver()方法
        // 注意更新当前页码 currPage
        this.$refs.loadRefresh.loadOver()
      },
      // 下拉刷新数据列表
      refresh() {
        console.log('refresh')
      },
			handleSearch(value){
      
           GetNewsKinds({parameter:value}).then(data => { 
					//data为一个数组，数组第一项为错误信息，第二项为返回数据
					var [error, res] = data;
					if(res.statusCode==200){
				
                if(res.data.flag==0){
				 uni.navigateTo({
					url: '/pages/doctor-list/info?id=' + res.data.id
				})
				}else if(res.data.flag==1){
				uni.navigateTo({
					url: '/pages/hospital-list/info?id=' + res.data.id
				})
				}else if(res.data.flag==2){
            	 uni.navigateTo({
					url: '/pages/uni-tabs/details?id='+res.data.id
				})
				}else{
				uni.showToast({
							icon: 'none',
							title: '无查询消息'
						})
				}
					}else{

                }
		   })

			},
			change(){

			},
			goAnswer(){
			uni.navigateTo({
					url: '/pages/answer-list/index'
				});
			},
			godoctor() {
				uni.navigateTo({
					url: '/pages/doctor-list/index'
				});
			},
			gohospital() {
				uni.navigateTo({
					url: '/pages/hospital-list/index'
				});
      },
      goquestions1(){
      uni.navigateTo({
					url: '/pages/answer-list/questions'
				});
      },
			goquestions() {
			uni.navigateTo({
					url: '/pages/answer-list/index'
				});
			}
		}
	}
</script>

<style>
	.content {
		text-align: center;
		height: 400upx;
	}

	.logo {
		height: 200upx;
		width: 200upx;
		margin-top: 200upx;
	}

	.title {
		font-size: 36upx;
		color: #8f8f94;
	}
</style>