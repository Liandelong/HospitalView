<template>
<view>
<view style="text-align:center;font-family:'黑体';font-size:30px">{{this.message.title}}</view>
<view>{{this.message.content}}</view>
</view>
</template>
<script>
		import {
		GetHealthNewByID
	} from '@/api/healthNews/healthNews.js'
export default {
    
    data(){
        return{
            message:{
                id:undefined, 
                title:undefined,
                author:undefined,
                time:undefined,
            }

        }
    },
    onLoad(data) {

        GetHealthNewByID(data.id).then(data => { 
					//data为一个数组，数组第一项为错误信息，第二项为返回数据
					var [error, res] = data;
					if(res.statusCode==200){
                        console.log(res.data.data)
						   Object.keys(res.data.data).forEach(key => {
							this.message[key] = res.data.data[key]
						  })
					}else{

                }
            })
    }

}
</script>