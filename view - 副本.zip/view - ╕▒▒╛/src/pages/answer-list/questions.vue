<template>
	<view class="ui-form ui-border-t">
		<form id="entry_form">
			<p />
			<view class="ui-form-item ui-border-b"  >
				<!-- <view> -->
				<label>
					提问：
				</label>
				<input type="title" id="name2" v-model="message.title"   placeholder="问题">
			<!-- </view> -->
			</view>




		</form>
		<view class="ui-btn-wrap">
			<view style="width:100%;">
				<button class="submit" type="primary" @tap="nextPage">提问</button>
			</view>
		</view>

	</view>

</template>
<script>
	import {
		CreateOrEditProblem
	} from '@/api/problems/problems.js'
export default {
	data(){
	return {
	message:{
	title:undefined,
	userId:undefined
		}
	}
	},
	methods: {
		nextPage(){
			var user_Message = uni.getStorageSync("user_Message");
			this.message.userId=user_Message.id
				CreateOrEditProblem(this.message).then(data => { 
					//data为一个数组，数组第一项为错误信息，第二项为返回数据
					var [error, res] = data;
					if(res.statusCode==200){
							uni.showToast({
							icon: 'success',
							title: '提问成功'
						})
				uni.switchTab({
				    url: '/pages/index/index'
				});
					}else{
					uni.showToast({
							icon: 'none',
							title: '提问失败'
						})
					}
					


				})

            
		},
	  },
	onLoad() {
	var user_Message = uni.getStorageSync("user_Message");
	 Object.keys(this.message).forEach(key => {
          this.message[key] = user_Message[key]
        })
  }
}
</script>
<style>
	.uni-form-item .title {
		padding: 20rpx 0;
		
    display: inline-block;
	}
</style>
