<template>
	<view class="content">
		<scroll-view
			style="width:100%;height: 100%;"
			scroll-y
			:scroll-top="scrollTop"
			@scrolltolower="loadMore"
			@scroll="scrollTopFun"
			:lower-threshold="50"
		>
			<!-- cSwiper组件
			 goUrl 为空时 无点击事件
			 dataList 数据
			 indicatorColor 指示点颜色
			 indicatorActiveColor 当前选中的指示点颜色
			 indicatorDots 是否显示面板指示点
			 titleShow 是否显示面标题
			 autoplay 是否自动切换
			 interval 自动切换时间间隔
			 duration 滑动动画时长
			-->
			<cSwiper
				:urls="componentSwiper.goUrl"
				:list="dataList"
				:indicatorColor="'#999'"
				:indicatorActiveColor="'#fff'"
				:indicatorDots="componentSwiper.indicatorDots"
				:titleShow="componentSwiper.titleShow"
				:autoplay="componentSwiper.autoplay"
				:interval="componentSwiper.interval"
				:duration="componentSwiper.duration"
			></cSwiper>
			<!-- 固定顶部内容 
			showComponent 控制显示隐藏
			-->
			<scroll-view
				id="tab-bar"
				class="uni-swiper-tab displayDiv"
				:class="showComponent ? 'topnav' : ''"
			>
				<view
					class="swiper-tab-list"
					v-for="(tab, index) in tabBars"
					:key="index"
					:id="tab.value"
					:data-current="index"
					@click="tapTab(index)"
				>
					<view
						class="tab-content"
						v-text="tab.name"
						:class="[tabIndex == index ? 'active' : '']"
					></view>
				</view>
			</scroll-view>
			<!-- 文章列表 -->
			<scroll-view id="list" :class="showComponent ? 'listActive' : ''" scroll-y @scrolltolower="loadMore(index1)">
				<nList :urls="NewsGoUrl" :list="dataList2"></nList>
				<view class="uni-tab-bar-loading" >
					<uni-load-more
						:loadingType="loadingType"
						:contentText="loadingText"
					></uni-load-more>
				</view>
			</scroll-view>
		</scroll-view>
	</view>
</template>

<script>
import cSwiper from '@/components/comp-swiper.vue';
import nList from '@/components/NewsList.vue';

import uniLoadMore from '@/components/uni-load-more.vue';
	import {
		GetAllProblems,
		GetUserProblems
	} from '@/api/problems/problems.js'
export default {
	components: {
		cSwiper,
		nList,
		uniLoadMore
	},
	data() {
		return {
			scrollComponents: '#tab-bar', // tab 容器 计算距离顶部距离使用
			scrollViewomponents: '#list', // 内容 容器 计算距离顶部距离使用
			showComponent: false, // 是否显示
			scrollTop: 0, // scroll-view组件 距离顶部距离，点击tab时间置顶使用
			tabIndex: 0, // tab组件选项卡事件参数
			dataList: [
				{
					img: '../../static/hen/1.jpg',
					title: '瑜伽真的能减肥吗',
					info: '瑜伽真的能减肥吗',
					another: '瑜伽真的能减肥吗',
					id: 1
				},
				{
					img: '../../static/hen/2.jpg',
					title: '怎么爱护心脏',
					info:'怎么爱护心脏',
					another: '怎么爱护心脏',
					id: 1
				},

            ],
            	dataList2:[],
			// 轮播图组件参数
			componentSwiper: {
				indicatorDots: false,
				autoplay: true,
				titleShow: true,
				interval: 2000,
				duration: 500,
				goUrl: ''
			},
			top: 0, // 顶部监听事件使用
			// 顶部菜单
			tabBars: [
				{
					name: '我的提问',
					value: 'demo'
				},
				{
					name: '热点提问',
					value: 'news'
				}
			],
			isClickChange: false,
			NewsGoUrl: '/pages/answer-list/indexhui', // 列表点击链接
			loadingType: 0, // 加载更多状态
			loadingText: {
				contentdown: '上拉显示更多',
				contentrefresh: '正在加载...',
				contentnomore: '没有更多数据了'
			}
		};
	},
	onLoad() {
			var user_Message = uni.getStorageSync("user_Message");

		GetUserProblems({"userId": user_Message.id}).then(data=>{
					var [error, res] = data;
					if(res.statusCode==200){
                        this.dataList2=res.data.data
					}else{

                }
	})
	},
	methods: {
		// 点击事件
		tap(o) {
			let _this = this;
			if (_this.goUrl != '') {
				uni.navigateTo({
					url: _this.goUrl + o
				});
			}
		},
		// 监听滑动事件
		scrollTopFun(e) {
			let _this = this;
			_this.top = e.detail.scrollTop;
			_this.getScrollTop();
		},
		// 计算距离
		getScrollTop() {
			let view = uni.createSelectorQuery().select(this.scrollComponents);
			let scrollView = uni.createSelectorQuery().select(this.scrollViewomponents);
			view.boundingClientRect(data => {
				// data.top  tab节点离页面顶部的距离为;
				if (data.top <= 0) {
					scrollView.boundingClientRect(scrollData=>{
						// data.top  内容节点离页面顶部的距离为;
						if(scrollData.top>0){
							this.showComponent = false;
						}else{
							this.showComponent = true;
						}
					}).exec();
				} else {
					this.showComponent = false;
				}
			}).exec();
		},
		// 滑动底部加载
		loadMore(e) {
			let _this = this;
			let list = _this.dataList;
			_this.loadingType = 1;
			setTimeout(() => {
				let li = {
					img: '../../static/logo.png',
					title: '幻灯' + e.timeStamp.toString(),
					info: '简介',
					another: '额外',
					id: e.timeStamp.toString()
				};
				list.push(li);
				_this.loadingType = 0;
			}, 1200);
		},
		// tabbar 点击事件
		async tapTab(e) {
			if (this.tabIndex === e) {
				return false;
			} else {
				uni.showLoading({
					title: '加载中'
				});
				let datas = await this.getDataList(e); //异步请求数据
				this.tabIndex = datas;
				this.scrollTop = 0;
            }
            
		},
		getData(e){
		if(e==1){
						GetAllProblems().then(data=>{
					var [error, res] = data;
					if(res.statusCode==200){

						this.dataList2=res.data.data

					}else{}	})
		}else{
			var user_Message = uni.getStorageSync("user_Message");
					GetUserProblems({"userId": user_Message.id}).then(data=>{
					var [error, res] = data;
					if(res.statusCode==200){
                        this.dataList2=res.data.data
					}else{

                }})
		}

		},
		getDataList(e) {
		
			let _this = this;
			return new Promise((res, rej) => {
				// 请求数据逻辑
				setTimeout(function() {
					_this.scrollTop = _this.top;
					uni.hideLoading();
					_this.getData(e);
					res(e);
				}, 200);
			});
		}
	}
};
</script>

<style>
@keyframes myfirst {
	from {
		top: -100upx;
	}
	to {
		top: 0;
	}
}
.content {
	position: fixed;
	width: 100%;
	height: 100%;
	text-align: center;
	background: #f2f2f5;
}
.uni-swiper-tab {
	background: #ffffff;
	border-bottom: 1px solid #f5f5f5;
}
.swiper-tab-list {
	flex: 1;
	width: 50%;
	padding: 10upx 0;
	box-sizing: border-box;
	letter-spacing: 5upx;
	text-indent: 1upx;
	display: inline-block;
	align-items: center;
}
.displayDiv {
	top: -100upx;
	z-index: 99;
	background: #fff;
	width: 100%;
	margin-top: 0 !important;
}
.topnav {
	position: fixed;
	animation: myfirst 0.2s;
	top: 0;
}
.listActive{
	margin-top: 78upx;
}
.tab-content {
	font-size: 32upx;
	border-bottom: 2px solid #ffffff;
	width: 50%;
	margin: 0 auto;
}
.active {
	font-size: 36upx;
	font-weight: 600;
	border-bottom: 2px solid #008395;
	color: #008395;
}
.uni-swiper-tab {
	display: flex;
	margin-top: 20upx;
}
</style>
