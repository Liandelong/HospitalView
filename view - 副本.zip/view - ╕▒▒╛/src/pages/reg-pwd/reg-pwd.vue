<template>
	<!-- 最后注册 -->
	<view class="page_reg">
		<!-- <text class="tip">短信验证码已发送至13678678909请查收</text> -->
		<view class="code">
			<input type="text" v-model="message.userName" placeholder="用户姓名" value="" />
		</view>
		<view class="code">
			<input type="text" v-model="message.telephone" placeholder="手机号码" value="" />
		</view>
				<view class="code">
			<input type="text" v-model="message.idCard" placeholder="身份证号" value="" />
		</view>
		<!-- <view class="code">
			<input type="text" value="" placeholder="验证码" />
			<button class="submit" type="primary">获取验证码</button>
		</view> -->
		<view class="pwd">
			<input password v-model="message.password" type="password" value="" placeholder="登录密码" />
		</view>
		<view class="pwd">
			<input password  v-model="message.password2" type="password" value="" placeholder="再一次输入登录密码" />
		</view>

		<view style="width:100%;">
			<button class="submit" type="primary" @tap="register">注册</button>
		</view>
	</view>
</template>

<script>
	import {
		CreateUser
	} from '@/api/register/register.js'
	export default {
		data() {
			return {
				message:{
				"userName":undefined,
  				"telephone": undefined,
				  "password": undefined,
				  "password2": undefined,
  				"idCard": undefined
				}
			};
		},
		methods: {
			register() {
				CreateUser(this.message).then(data => { 
					//data为一个数组，数组第一项为错误信息，第二项为返回数据
					var [error, res] = data;
					if(res.statusCode==200){
							uni.showToast({
							icon: 'success',
							title: '注册成功'
						})
						             uni.navigateTo({
					url: '/'
				})
					}else{
					uni.showToast({
							icon: 'none',
							title: '注册失败'
						})
					}
					


				})
			}


		}
	}
</script>

<style>
	page {
		background-color: #f5f6f8;
	}
</style>
<style lang="scss" scoped>
	$text-color: #B6B6B6;
	$form-border-color: rgba(214, 214, 214, 1);

	.page_reg {
		height: 100%;
		margin: 30px;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.tip {
		margin-top: 30px;
		font-size: 13px;
		color: $text-color;
	}

	.code {
		width: 100%;
		min-height: 65px;
		margin-top: 30px;
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		border-bottom: 1px solid $form-border-color;

		.submit {
			color: white;
			background-color: #1296db;
			-webkit-tap-highlight-color: #1296db;

			&:active {
				color: #B6B6B6;
				background-color: #1296db;
			}
		}
	}

	.pwd {
		width: 100%;
		margin-top: 10px;
		min-height: 65px;
		display: flex;
		flex-direction: row;
		align-items: center;
		border-bottom: 1px solid $form-border-color;
	}

	.protocol_tip {
		font-size: 16px;
		color: $text-color;
	}

	.link {
		color: #3a8de8;
	}
</style>