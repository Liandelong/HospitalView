//+
import global from '@/components/common.vue'
var Ip =global.httpUrl


//登录
export function GetNewsKinds(data) {
    return uni.request({
    url: Ip+"/NewsKinds/GetNewsKinds", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}

export function GetNewsKindByID(data) {
    return uni.request({
    url: Ip+"/NewsKinds/GetNewsKindByID/"+data, //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "get",
})
}