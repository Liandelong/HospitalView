//+
import global from '@/components/common.vue'
var Ip =global.httpUrl


//登录
export function GetHospitals(data) {
    return uni.request({
    url: Ip+"/Hospital/GetHospitals", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}

export function GetHospitalByID(data) {
    return uni.request({
    url: Ip+"/Hospital/GetHospitalByID/"+data, //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "get",
})
}