//+
import global from '@/components/common.vue'
var Ip =global.httpUrl


//登录
export function GetNewsKinds(data) {
    return uni.request({
    url: Ip+"/DiseaseKinds/GetDiseaseKinds", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}
export function GetHealthNews(data) {
    return uni.request({
    url: Ip+"/DiseaseKnowledge/GetDiseaseKnowledgesAPI?newsKindId="+data.newsKindId, //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}
export function GetNewsKindByID(data) {
    return uni.request({
    url: Ip+"/DiseaseKnowledge/GetDiseaseKnowledgeByID/"+data, //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "get",
})
}