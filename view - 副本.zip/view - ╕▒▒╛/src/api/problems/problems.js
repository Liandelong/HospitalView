//+
import global from '@/components/common.vue'
var Ip =global.httpUrl


//全部用户
export function GetAllProblems(data) {
    return uni.request({
    url: Ip+"/Problems/GetAllProblems", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}

//全部用户
export function GetUserProblems(data) {
    return uni.request({
    url: Ip+"/Problems/GetUserProblems", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}

//全部用户
export function CreateOrEditProblem(data) {
    return uni.request({
    url: Ip+"/Problems/CreateOrEditProblem", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}