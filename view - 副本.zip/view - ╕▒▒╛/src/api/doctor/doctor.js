//+
import global from '@/components/common.vue'
var Ip =global.httpUrl


//登录
export function GetDoctors(data) {
    return uni.request({
    url: Ip+"/Doctor/GetDoctors", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}

export function GetDoctorByID(data) {
    return uni.request({
    url: Ip+"/Doctor/GetDoctorByID/"+data, //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "get",
})
}