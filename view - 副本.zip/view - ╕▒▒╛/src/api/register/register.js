//+
import global from '@/components/common.vue'
var Ip =global.httpUrl
//注册
export function CreateUser(data) {
    return uni.request({
    url: Ip+"/Login/Register", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method:"post",
})
}
//登录
export function Login(data) {
    return uni.request({
    url: Ip+"/Login/Login", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method:"post",
})
}
//登录
export function GetNewsKinds(data) {
    return uni.request({
    url: Ip+"/Search/GetSearchs", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method:"post",
})
}