//+
import global from '@/components/common.vue'
var Ip =global.httpUrl


//登录
export function GetAnswers(data) {
    return uni.request({
    url: Ip+"/Answers/GetAnswers", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}
//登录
export function GetDoctorAndPatientAnswers(data) {
    return uni.request({
    url: Ip+"/Answers/GetDoctorAndPatientAnswers", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}
export function UserAnswer(data) {
    return uni.request({
    url: Ip+"/Answers/UserAnswer", //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}