//+
import global from '@/components/common.vue'
var Ip =global.httpUrl


//登录
export function GetHealthNews(data) {
    return uni.request({
    url: Ip+"/HealthNews/GetHealthNewsAPI?newsKindId="+data.newsKindId, //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "post",
})
}

export function GetHealthNewByID(data) {
    return uni.request({
    url: Ip+"/HealthNews/GetHealthNewByID/"+data, //仅为示例，并非真实接口地址。 
    data: data,
    header: {'custom-header': 'application/json'},
    method: "get",
})
}