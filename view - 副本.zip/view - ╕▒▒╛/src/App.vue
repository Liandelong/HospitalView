<script>
	export default {
		
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onLaunch: function() {},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
  @import './css/frozenui.css';
   @import './css/animation.css';
	 @import './css/icon.css';
	/* @import './css/main.css';*/
      @import './css/uni.css'; 
	/*每个页面公共css */
</style>
