import Vue from 'vue'
import App from './App'
import cComponent from '@/components/index.js'

Vue.use(cComponent)
Vue.config.productionTip = false
App.mpType = 'app'

const app = new Vue({
  ...App
})
app.$mount()
